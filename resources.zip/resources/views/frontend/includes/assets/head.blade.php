<!--Favicon-->
<link rel="icon" href="{{ asset('/') }}frontend/assets/img/favicon.png" type="image/jpg" />

<!-- Bootstrap CSS -->
<link href="{{ asset('/') }}frontend/assets/css/bootstrap.min.css" rel="stylesheet">
<!-- Font Awesome CSS-->
<link href="{{ asset('/') }}frontend/assets/css/font-awesome.min.css" rel="stylesheet">
<!-- Line Awesome CSS -->
<link href="{{ asset('/') }}frontend/assets/css/line-awesome.min.css" rel="stylesheet">
<!-- Animate CSS-->
<link href="{{ asset('/') }}frontend/assets/css/animate.css" rel="stylesheet">
<!-- Bar Filler CSS -->
<link href="{{ asset('/') }}frontend/assets/css/barfiller.css" rel="stylesheet">
<!-- Magnific Popup Video -->
<link href="{{ asset('/') }}frontend/assets/css/magnific-popup.css" rel="stylesheet">
<!-- Flaticon CSS -->
<link href="{{ asset('/') }}frontend/assets/css/flaticon.css" rel="stylesheet">
<!-- Owl Carousel CSS -->
<link href="{{ asset('/') }}frontend/assets/css/owl.carousel.css" rel="stylesheet">
<!-- Style CSS -->
<link href="{{ asset('/') }}frontend/assets/css/style.css" rel="stylesheet">
<!-- Responsive CSS -->
<link href="{{ asset('/') }}frontend/assets/css/responsive.css" rel="stylesheet">
<!-- Toastr CSS -->
<link href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" rel="stylesheet">
{!! $basicSetting->seo_header ?? '' !!}
@yield('style')
@stack('style')
