<div class="header-top dark-bg">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-12 col-sm-12">
                <div class="contact-info">
                    <i class="las la-envelope"></i> info@fossil.com
                    <i class="las la-map-marker"></i> 66, Broklyn St, New York, USA
                </div>
            </div>
            <div class="col-lg-6 col-md-12 col-sm-12 text-end">
                <div class="site-info">
                    Turning big ideas into great services!
                    <div class="social-area">
                        <a href="#"><i class="lab la-facebook-f"></i></a>
                        <a href="#"><i class="lab la-instagram"></i></a>
                        <a href="#"><i class="lab la-twitter"></i></a>
                        <a href="#"><i class="la la-skype"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH H:\wamp64\www\PRACTICE-SECTIONS\CLIENT-PROJECTS-DEVELOPMENT\fossil-gas-station\resources\views/frontend/includes/header-top.blade.php ENDPATH**/ ?>