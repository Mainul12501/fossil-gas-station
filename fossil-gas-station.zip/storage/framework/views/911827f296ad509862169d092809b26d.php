

<div class="client-area pt-50 pb-40">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="logo-carousel owl-carousel">
                    <?php $__currentLoopData = $gasStationsLogos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gasStationsLogo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="single-logo-wrapper">
                            <div class="logo-inner-item">
                                <img src="<?php echo e(asset($gasStationsLogo->logo ?? 'frontend/assets/img/client/1.jpg')); ?>" alt="<?php echo e($gasStationsLogo->name); ?>" style="width: 150px; height: 61px">
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH H:\wamp64\www\PRACTICE-SECTIONS\CLIENT-PROJECTS-DEVELOPMENT\fossil-gas-station\resources\views/frontend/includes/brand-slider.blade.php ENDPATH**/ ?>