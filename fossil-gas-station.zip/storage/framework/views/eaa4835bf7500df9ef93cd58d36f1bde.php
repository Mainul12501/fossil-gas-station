<?php $__env->startSection('title', 'Home Slider'); ?>
<?php $__env->startSection('breadcrumb', 'Home Slider'); ?>

<?php $__env->startSection('body'); ?>
    <div class="row py-5">
        <div class="col-md-6 mx-auto">
            <div class="card">
                <div class="card-header bg-primary">
                    <h4 class="text-white float-start">Home Slider Create</h4>
                    <a href="<?php echo e(route('home-sliders.index')); ?>" class="text-white float-end f-s-20">
                        <i class="mdi mdi-page-previous-outline"></i>
                    </a>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(isset($homeSlider) ? route('home-sliders.update', $homeSlider->id) : route('home-sliders.store')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php if(isset($homeSlider)): ?>
                            <?php echo method_field('put'); ?>
                        <?php endif; ?>
                        <div>
                            <label for="">Tiny Title</label>
                            <input type="text" name="tiny_title" <?php echo e(isset($isShown) ? 'readonly' : ''); ?> class="form-control" value="<?php echo e(isset($homeSlider) ? $homeSlider->tiny_title : ''); ?>" />
                        </div>
                        <div>
                            <label for="">Title</label>
                            <textarea name="title" <?php echo e(isset($isShown) ? 'disabled' : ''); ?> class="form-control" id="elm1" cols="30" rows="2"><?php echo isset($homeSlider) ? $homeSlider->title : ''; ?></textarea>
                        </div>
                        <div class="mt-2">
                            <label for="">Description</label>
                            <textarea name="description" <?php echo e(isset($isShown) ? 'disabled' : ''); ?> class="form-control" id="elm1" cols="30" rows="2"><?php echo isset($homeSlider) ? $homeSlider->description : ''; ?></textarea>
                        </div>
                        <div>
                            <label for="">Banner Image</label>
                            <?php if(!isset($isShown)): ?>
                                <input type="file" name="banner_image" class="form-control" accept="image/*" />
                            <?php endif; ?>
                            <?php if(isset($homeSlider->banner_image)): ?>
                                <img src="<?php echo e(asset($homeSlider->banner_image)); ?>" alt="" style="height: 60px" />
                            <?php endif; ?>
                        </div>
                        <div class="mt-2">
                            <label for="">Active</label>
                            <div>
                                <div class="material-switch">
                                    <input id="someSwitchOptionInfo" name="status" <?php echo e(isset($isShown) ? 'disabled' : ''); ?>  class="form-check-input success check-outline outline-success" type="checkbox" <?php echo e(isset($homeSlider) && $homeSlider->status == 0 ? '' : 'checked'); ?> />
                                    <label for="someSwitchOptionInfo" class="label-info"></label>
                                </div>
                            </div>
                        </div>
                        <?php if(!isset($isShown)): ?>
                        <div>
                            <input type="submit" class="btn btn-success btn-sm float-end" value="<?php echo e(isset($homeSlider) ? 'Update' : 'Create'); ?> Home Slider" />
                        </div>
                        <?php endif; ?>
                    </form>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <!--tinymce js-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/tinymce/5.3.2/tinymce.min.js" integrity="sha512-9w/jRiVYhkTCGR//GeGsRss1BJdvxVj544etEHGG1ZPB9qxwF7m6VAeEQb1DzlVvjEZ8Qv4v8YGU8xVPPgovqg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <script>

        tinymce.init({
            selector: 'textarea',
            height: 200,
            menubar: false,
            plugins: [
                'advlist autolink lists link image charmap print preview anchor',
                'searchreplace visualblocks code fullscreen',
                'insertdatetime media table paste code help wordcount'
            ],
            toolbar: 'undo redo | formatselect | ' +
                'bold italic backcolor | alignleft aligncenter ' +
                'alignright alignjustify | bullist numlist outdent indent | ' +
                'removeformat | help',
            content_style: 'body { font-family:Helvetica,Arial,sans-serif; font-size:14px }'
        });


    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\wamp64\www\PRACTICE-SECTIONS\CLIENT-PROJECTS-DEVELOPMENT\fossil-gas-station\resources\views/backend/home-slider/create.blade.php ENDPATH**/ ?>