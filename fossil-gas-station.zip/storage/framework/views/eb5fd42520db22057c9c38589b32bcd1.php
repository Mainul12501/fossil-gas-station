<?php $__env->startSection('title', 'Locations page'); ?>

<?php $__env->startSection('body'); ?>

    <!-- Breadcroumb Area -->














    <section class="py-5 location-banner-min-height" style="background-image: url(<?php echo e(asset('frontend/assets/img/gas-custom/1.jpeg')); ?>); background-size: cover; background-repeat: no-repeat;">
        <div class="container">
            <div class="row">
                <div class="col-md-4"></div>
                <div class="col-md-4">
                    <div class="text-center">
                        <div class="card bg-transparent border-0">

                            <div class="card-body ">
                                <h1 class="text-white">Find Us</h1>
                                <p class="text-white">Explore what we have to offer</p>
                                <div>
                                    <a href="#locationsArea" class="btn btn-outline-primary text-white">Find A Station Near You</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4"></div>
            </div>
        </div>
    </section>












































































































    <section class="py-5" id="locationsArea">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div>
                        <div id="map" style="min-height: 600px"></div>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('style'); ?>
    <style>
        .location-banner-min-height {min-height: 450px}
        @media screen and (max-width: 768px) {
            .location-banner-min-height {min-height: 300px}
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        $(function () {
            let height = 0;
            $('.common-height').each(function () {
                if ($(this).height() > height) {
                    height = $(this).height();
                }
            });
            console.log(height);
            $('.common-height .single-serv-item').css('height', height+'px');
        })
    </script>
    <script>
        function initMap() {
            const myLatLng = { lat: 36.7783, lng: -119.4179 };
            const map = new google.maps.Map(document.getElementById("map"), {
                zoom: 6,
                center: myLatLng,
            });
            var locations = <?php echo e(Js::from($locations)); ?>;
            var infowindow = new google.maps.InfoWindow();
            var marker, i;
            for (i = 0; i < locations.length; i++) {
                marker = new google.maps.Marker({
                    position: new google.maps.LatLng(locations[i][1], locations[i][2]),
                    map: map
                });
                google.maps.event.addListener(marker, 'click', (function(marker, i) {
                    return function() {
                        infowindow.setContent(locations[i][0]);
                        infowindow.open(map, marker);
                    }
                })(marker, i));
            }
        }
        window.initMap = initMap;
    </script>
    <script type="text/javascript" loading="async" src="https://maps.google.com/maps/api/js?key=<?php echo e(env('GOOGLE_MAP_KEY')); ?>&callback=initMap" ></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\wamp64\www\PRACTICE-SECTIONS\CLIENT-PROJECTS-DEVELOPMENT\fossil-gas-station\resources\views/frontend/common-pages/locations.blade.php ENDPATH**/ ?>