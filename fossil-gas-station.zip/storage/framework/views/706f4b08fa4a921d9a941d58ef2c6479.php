<div class="newsletter-section">
    <div class="container">
        <div class="newsletter-content d-flex align-items-center justify-content-between">
            <div class="section-title">
                <h2 class="text-white">Subscribe newsletter <br> For Any Update</h2>
            </div>
            <div class="subscribed-form d-flex">
                <form action="<?php echo e(route('newsletters.store')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <input type="email" name="email" placeholder="Enter Your Mail">
                    <input type="submit" value="Subscribe Now">
                </form>
            </div>
        </div>
    </div>
</div>
<?php /**PATH H:\wamp64\www\PRACTICE-SECTIONS\CLIENT-PROJECTS-DEVELOPMENT\fossil-gas-station\resources\views/frontend/includes/newsletter.blade.php ENDPATH**/ ?>