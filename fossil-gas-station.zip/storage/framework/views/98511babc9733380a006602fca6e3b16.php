<?php $__env->startSection('title', 'Gas Stations'); ?>
<?php $__env->startSection('breadcrumb', 'Gas Stations'); ?>

<?php $__env->startSection('body'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card card-hover">
                    <div class="card-header bg-info">
                        <h4 class="text-white float-start">Gas Stations</h4>

                            <a href="<?php echo e(isset($_GET['station']) ? route('gas-stations.create', ['station' => $_GET['station']]) : route('gas-stations.create')); ?>" class="rounded-circle float-end text-white text-light f-s-20 ">
                                <span class="f-s-22 border-5"><i class="mdi mdi-plus-circle-outline"></i></span>
                            </a>

                    </div>
                    <div class="card-body ">
                        <div class="table-responsive">
                            <table class="table responsive dt-responsive table-responsive"  id="dataTable">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th>P. Status</th>
                                    <th>Name</th>
                                    <th>Images</th>
                                    <th>Overview</th>
                                    <th>Office Info</th>
                                    <th>Social</th>

                                    <th>Key People</th>



                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $gasStations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $gasStation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($gasStation->gas_station_id == 0 ? 'Parent' : $gasStation->gasStation->name ?? ''); ?></td>
                                         <td><a href="<?php echo e(route('gas-stations.index', ['station' => $gasStation->id])); ?>"><?php echo e($gasStation->name ?? ''); ?></a></td>
                                        <td>
                                            <div>
                                                <span>Logo: </span>
                                                <a href="<?php echo e(asset($gasStation->logo ?? '')); ?>" target="_blank"><img src="<?php echo e(asset($gasStation->logo ?? '')); ?>" class="" alt="station-logo-<?php echo e($key); ?>" style="height: 40px" /></a>
                                            </div>
                                            <div class="mt-2">
                                                <span>Main Image: </span>
                                                <a href="<?php echo e(asset($gasStation->main_image ?? '')); ?>" target="_blank"><img src="<?php echo e(asset($gasStation->main_image ?? '')); ?>" class="" alt="station-main-image-<?php echo e($key); ?>" style="height: 40px" /></a>
                                            </div>
                                            <div class="mt-2">
                                                <span>Sub Images: </span>
                                                <?php if(isset($gasStation->sub_images)): ?>
                                                    <?php $__currentLoopData = json_decode($gasStation->sub_images); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $singleImage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <a href="<?php echo e(asset($singleImage ?? '')); ?>" class=""><img src="<?php echo e(asset($singleImage ?? '')); ?>" class="p-1" alt="station-sub-image-<?php echo e($key); ?>" style="height: 40px" /></a>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                        <td><?php echo $gasStation->overview ?? ''; ?></td>
                                        <td>
                                            <div>
                                                <span>Phone: <?php echo e($gasStation->office_phone_number); ?></span> <br>
                                                <span>Address: <?php echo $gasStation->office_address; ?></span> <br>
                                            </div>
                                            <div class="">
                                                <p><span>State: <?php echo e($gasStation->state); ?></span>, <span>State Id: <?php echo e($gasStation->state_id); ?></span>, <span>Zip Code: <?php echo e($gasStation->zip_code); ?></span>, </p>
                                            </div>
                                        </td>
                                        <td>
                                            <p>
                                                <span class="me-2"><a href="<?php echo e($gasStation->fb ?? ''); ?>" target="_blank"><i class="fa fa-facebook-f"></i></a></span>
                                                <span class="me-2"><a href="https://wa.me/<?php echo e($gasStation->whatsapp ?? ''); ?>" target="_blank"><i class="fa fa-whatsapp"></i></a></span>
                                                <span class="me-2"><a href="<?php echo e($gasStation->insta ?? ''); ?>" target="_blank"><i class="fa fa-instagram"></i></a></span>
                                                <span class="me-2"><a href="<?php echo e($gasStation->telegram ?? ''); ?>" target="_blank"><i class="fa fa-telegram"></i></a></span>
                                                <span class="me-2"><a href="<?php echo e($gasStation->linkedin ?? ''); ?>" target="_blank"><i class="fa fa-linkedin"></i></a></span>
                                                <span class="me-2"><a href="<?php echo e($gasStation->skype ?? ''); ?>" target="_blank"><i class="fa fa-skype"></i></a></span>
                                            </p>
                                        </td>





                                        <td>
                                            <?php echo e(isset($gasStation->gasStationKeyPeople) ? $gasStation->gasStationKeyPeople->name : ''); ?>

                                        </td>



                                        <td><?php echo e($gasStation->status == 1 ? 'Published' : 'Unpublished'); ?></td>
                                        <td class="">
                                            
                                            <a href="<?php echo e(route('gas-stations.index', ['station' => $gasStation->id])); ?>" class="btn btn-sm btn-primary">
                                                <i class="mdi mdi-arrow-all"></i>
                                            </a> <br>
                                            <a href="<?php echo e(route('gas-stations.show', $gasStation->id)); ?>" class="btn btn-sm btn-primary mt-1">
                                                <i class="mdi mdi-eye"></i>
                                            </a> <br>
                                            <a href="<?php echo e(route('gas-stations.edit', ['gas_station' => $gasStation->id, 'station' => $gasStation->gas_station_id])); ?>" class="btn btn-sm btn-warning mt-1">
                                                <i class="mdi mdi-square-edit-outline"></i>
                                            </a> <br>
                                            
                                            
                                            <form class="d-inline" action="<?php echo e(route('gas-stations.destroy', $gasStation->id)); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('delete'); ?>
                                                <button type="submit" class="btn btn-sm btn-danger delete-data mt-1">
                                                    <i class="mdi mdi-trash-can-outline"></i>
                                                </button>
                                            </form>
                                            
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>frontend/assets/css/font-awesome.min.css">

<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>

<?php echo $__env->make("backend.includes.asset.plugin-files.datatable", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<script>
    // let table = new DataTable('#dataTable');
    // $('#dataTable').DataTable( {
    //     responsive: true
    // } );
</script>
<?php echo $__env->make("backend.includes.asset.plugin-files.sweet-alert-2", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\wamp64\www\PRACTICE-SECTIONS\CLIENT-PROJECTS-DEVELOPMENT\fossil-gas-station\resources\views/backend/gas-station/station/index.blade.php ENDPATH**/ ?>