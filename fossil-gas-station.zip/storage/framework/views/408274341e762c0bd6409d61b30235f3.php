
<link rel="stylesheet" href="<?php echo e(asset('/')); ?>backend/dist/libs/datatables.net-bs5/css/dataTables.bootstrap5.min.css">
<script src="<?php echo e(asset('/')); ?>backend/dist/libs/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?php echo e(asset('/')); ?>backend/dist/js/pages/datatable/custom-datatable.js"></script>
<script>
    $(function () {
        $('#dataTable').DataTable({
            responsive: true
        });
    })
</script>
<?php /**PATH H:\wamp64\www\PRACTICE-SECTIONS\CLIENT-PROJECTS-DEVELOPMENT\fossil-gas-station\resources\views/backend/includes/asset/plugin-files/datatable.blade.php ENDPATH**/ ?>