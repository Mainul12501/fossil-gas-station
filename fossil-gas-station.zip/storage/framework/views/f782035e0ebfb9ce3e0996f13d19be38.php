<meta name="keywords" content="sm technology, sm technology, sms, school management system, modern school management system">
<meta name="description" content="SM Technology SMS is a modern school management system.">

<?php echo $__env->yieldPushContent('meta'); ?>
<?php /**PATH H:\wamp64\www\PRACTICE-SECTIONS\CLIENT-PROJECTS-DEVELOPMENT\fossil-gas-station\resources\views/backend/includes/meta.blade.php ENDPATH**/ ?>