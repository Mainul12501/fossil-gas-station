<?php $__env->startSection('title', 'Station Employee'); ?>
<?php $__env->startSection('breadcrumb', 'Station Employee'); ?>

<?php $__env->startSection('body'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card card-hover">
                    <div class="card-header bg-info">
                        <h4 class="text-white float-start">Station Employee</h4>

                            <a href="<?php echo e(route('gas-station-employees.create')); ?>" class="rounded-circle float-end text-white text-light f-s-20 ">
                                <span class="f-s-22 border-5"><i class="mdi mdi-plus-circle-outline"></i></span>
                            </a>

                    </div>
                    <div class="card-body">
                        <table class="table" id="dataTable">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>P. Image</th>
                                <th>Name</th>
                                <th>Roles</th>
                                <th>Overview</th>
                                <th>Social</th>


                                <th>Slug</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td>
                                        <img src="<?php echo e(asset($employee->profile_image ?? '')); ?>" alt="employee-image-<?php echo e($key); ?>" style="height: 60px" />
                                    </td>
                                    <td><?php echo e($employee->name ?? ''); ?></td>
                                    <td>
                                        <?php $__currentLoopData = $employee->gasStationEmployeeRoles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gasStationEmployeeRole): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span class="badge bg-primary"><?php echo e($gasStationEmployeeRole->name); ?></span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td><?php echo $employee->overview ?? ''; ?></td>
                                    <td>
                                        <p>
                                            <span class="me-2"><a href="<?php echo e($employee->fb ?? ''); ?>" target="_blank"><i class="fa fa-facebook-f"></i></a></span>
                                            <span class="me-2"><a href="<?php echo e($employee->x ?? ''); ?>" target="_blank"><i class="fa fa-twitter"></i></a></span>
                                            <span class="me-2"><a href="<?php echo e($employee->linkedin ?? ''); ?>" target="_blank"><i class="fa fa-linkedin"></i></a></span>
                                            <span class="me-2"><a href=" https://wa.me/<?php echo e($employee->whatsapp ?? ''); ?>" target="_blank"><i class="fa fa-whatsapp"></i></a></span>
                                        </p>
                                    </td>


                                    <td><?php echo e($employee->slug ?? ''); ?></td>
                                    <td><?php echo e($employee->status == 1 ? 'Published' : 'Unpublished'); ?></td>
                                    <td class="">

                                            <a href="<?php echo e(route('gas-station-employees.show', $employee->id)); ?>" class="btn btn-sm btn-primary">
                                                <i class="mdi mdi-eye"></i>
                                            </a>
                                            <a href="<?php echo e(route('gas-station-employees.edit', $employee->id)); ?>" class="btn btn-sm btn-warning">
                                                <i class="mdi mdi-square-edit-outline"></i>
                                            </a>


                                            <form class="d-inline" action="<?php echo e(route('gas-station-employees.destroy', $employee->id)); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('delete'); ?>
                                                <button type="submit" class="btn btn-sm btn-danger delete-data">
                                                    <i class="mdi mdi-trash-can-outline"></i>
                                                </button>
                                            </form>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>frontend/assets/css/font-awesome.min.css">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>

<?php echo $__env->make("backend.includes.asset.plugin-files.datatable", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make("backend.includes.asset.plugin-files.sweet-alert-2", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\wamp64\www\PRACTICE-SECTIONS\CLIENT-PROJECTS-DEVELOPMENT\fossil-gas-station\resources\views/backend/gas-station/employee/index.blade.php ENDPATH**/ ?>