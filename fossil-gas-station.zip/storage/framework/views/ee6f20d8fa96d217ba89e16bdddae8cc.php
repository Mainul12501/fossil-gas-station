<?php $__env->startSection('title', 'Contact Page'); ?>

<?php $__env->startSection('body'); ?>

    <!-- Breadcroumb Area -->

    <div class="breadcroumb-area bread-bg">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcroumb-title">
                        <h1>Contact</h1>
                        <h6><a href="<?php echo e(route('home')); ?>">Home</a> / Contact</h6>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Contact Area -->

    <div id="contact-us" class="contact-us-area section-padding">
        <div class="container">
            <div class="contact-us-wrapper">
                <div class="row gx-0">
                    <div class="col-lg-3 col-md-6 col-12">
                        <div class="contact-us-inner">
                            <div class="info-i"><span><i class="las la-map-marker"></i></span></div>
                            <h5>Location</h5>
                            <p><?php echo $basicSetting->address ?? 'Dhaka Bangladesh'; ?></p>

                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-12">
                        <div class="contact-us-inner">
                            <div class="info-i"><span><i class="las la-clock"></i></span></div>
                            <h5>Office Hour</h5>
                            <p>Monday-Friday <br>08.00-20.00</p>

                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-12">
                        <div class="contact-us-inner">
                            <div class="info-i"><span><i class="las la-mobile"></i></span></div>
                            <h5>Phone Number</h5>
                            <p><?php echo e($basicSetting->phone ?? '016444'); ?> <br>(+3)112-976-2067</p>

                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-12">
                        <div class="contact-us-inner">
                            <div class="info-i"><span><i class="las la-envelope"></i></span></div>
                            <h5>E-mail Address</h5>
                            <p><?php echo e($basicSetting->email ?? 'site email'); ?><br>info@webmail.com</p>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- Contact Form -->

    <div id="contact-page" class="contact-section blue-bg section-padding">
        <div class="overlay-2"></div>
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-12 text-center wow fadeInRight">
                    <div class="contact-form-wrapper">
                        <div class="section-title">
                            <h2>Get in <b>Touch</b></h2>
                        </div>
                        <div class="contact-form">
                            <form action="<?php echo e(route('new-contact')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-lg-6 col-md-6 col-12">
                                        <input type="text" placeholder="Your Name" name="name" required />
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-12">
                                        <input type="email" placeholder="E-mail" name="email" required >
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-12">
                                        <input type="tel" placeholder="Phone Number" name="phone">
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-12">
                                        <input type="text" placeholder="Subject" name="subject">
                                    </div>
                                    <div class="col-lg-12">
                                        <textarea name="message" id="message"  cols="30" rows="10" placeholder="Write Message"></textarea>
                                    </div>
                                    <div class="col-lg-12 col-md-6 col-12 text-center">
                                        <button class="main-btn">Get A Quote</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Client Section -->















































<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\wamp64\www\PRACTICE-SECTIONS\CLIENT-PROJECTS-DEVELOPMENT\fossil-gas-station\resources\views/frontend/common-pages/contact.blade.php ENDPATH**/ ?>