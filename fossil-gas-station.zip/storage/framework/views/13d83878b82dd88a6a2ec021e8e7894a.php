<!--Favicon-->
<link rel="icon" href="<?php echo e(asset('/')); ?>frontend/assets/img/favicon.png" type="image/jpg" />

<!-- Bootstrap CSS -->
<link href="<?php echo e(asset('/')); ?>frontend/assets/css/bootstrap.min.css" rel="stylesheet">
<!-- Font Awesome CSS-->
<link href="<?php echo e(asset('/')); ?>frontend/assets/css/font-awesome.min.css" rel="stylesheet">
<!-- Line Awesome CSS -->
<link href="<?php echo e(asset('/')); ?>frontend/assets/css/line-awesome.min.css" rel="stylesheet">
<!-- Animate CSS-->
<link href="<?php echo e(asset('/')); ?>frontend/assets/css/animate.css" rel="stylesheet">
<!-- Bar Filler CSS -->
<link href="<?php echo e(asset('/')); ?>frontend/assets/css/barfiller.css" rel="stylesheet">
<!-- Magnific Popup Video -->
<link href="<?php echo e(asset('/')); ?>frontend/assets/css/magnific-popup.css" rel="stylesheet">
<!-- Flaticon CSS -->
<link href="<?php echo e(asset('/')); ?>frontend/assets/css/flaticon.css" rel="stylesheet">
<!-- Owl Carousel CSS -->
<link href="<?php echo e(asset('/')); ?>frontend/assets/css/owl.carousel.css" rel="stylesheet">
<!-- Style CSS -->
<link href="<?php echo e(asset('/')); ?>frontend/assets/css/style.css" rel="stylesheet">
<!-- Responsive CSS -->
<link href="<?php echo e(asset('/')); ?>frontend/assets/css/responsive.css" rel="stylesheet">
<!-- Toastr CSS -->
<link href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" rel="stylesheet">
<style>
    .text-justify {text-align: justify}
</style>
<?php echo $basicSetting->seo_header ?? ''; ?>

<?php echo $__env->yieldContent('style'); ?>
<?php echo $__env->yieldPushContent('style'); ?>
<?php /**PATH H:\wamp64\www\PRACTICE-SECTIONS\CLIENT-PROJECTS-DEVELOPMENT\fossil-gas-station\resources\views/frontend/includes/assets/head.blade.php ENDPATH**/ ?>