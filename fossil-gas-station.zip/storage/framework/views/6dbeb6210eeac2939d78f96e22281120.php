<?php $__env->startSection('title', 'Employee Role'); ?>

<?php $__env->startSection('body'); ?>
    <div class="row py-5">
        <div class="col-md-6 mx-auto">
            <div class="card">
                <div class="card-header bg-primary">
                    <h4 class="text-white float-start">Employee Role Create</h4>
                    <a href="<?php echo e(route('employee-roles.index')); ?>" class="text-white float-end f-s-20">
                        <i class="mdi mdi-page-previous-outline"></i>
                    </a>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(isset($employeeRole) ? route('employee-roles.update',['employee_role' => $employeeRole->id]) : route('employee-roles.store')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php if(isset($employeeRole)): ?>
                            <?php echo method_field('put'); ?>
                        <?php endif; ?>
                        <div>
                            <label for="">Name</label>
                            <input type="text" name="name" class="form-control" value="<?php echo e(isset($employeeRole) ? $employeeRole->name : ''); ?>" />
                        </div>

                        <div class="mt-2">
                            <label for="">Active</label>
                            <div>
                                <div class="material-switch">
                                    <input id="someSwitchOptionInfo" name="status" class="form-check-input success check-outline outline-success" type="checkbox" <?php echo e(isset($employeeRole) && $employeeRole->status == 0 ? '' : 'checked'); ?> />
                                    <label for="someSwitchOptionInfo" class="label-info"></label>
                                </div>
                            </div>
                        </div>
                        <div>
                            <input type="submit" class="btn btn-success btn-sm float-end" value="<?php echo e(isset($employeeRole) ? 'Update' : 'Create'); ?> Employee Role" />
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <!--tinymce js-->






















<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\wamp64\www\PRACTICE-SECTIONS\CLIENT-PROJECTS-DEVELOPMENT\fossil-gas-station\resources\views/backend/gas-station/employee-role/create.blade.php ENDPATH**/ ?>