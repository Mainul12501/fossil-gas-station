<header class="header-area">
    <div class="sticky-area">
        <div class="navigation">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-3">

                        <div class="logo">
                            <a class="navbar-brand" href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset(isset($basicSetting) ? $basicSetting->logo : 'frontend/assets/img/logo.png' )); ?>" alt="site logo" style="width: 190px; height: 50px"></a>
                        </div>

                    </div>
                    <div class="col-lg-6">
                        <div class="main-menu">
                            <nav class="navbar navbar-expand-lg">
                                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                                    <span class="navbar-toggler-icon"></span>
                                    <span class="navbar-toggler-icon"></span>
                                    <span class="navbar-toggler-icon"></span>
                                </button>

                                <div class="collapse navbar-collapse justify-content-center" id="navbarSupportedContent">
                                    <ul class="navbar-nav">
                                        <li class="nav-item">
                                            <a class="nav-link <?php echo e(request()->is('/') ? 'active' : ''); ?>" href="<?php echo e(route('home')); ?>">Home</a>

                                        </li>

                                        <li class="nav-item">
                                            <a class="nav-link <?php echo e(request()->is('about-us') ? 'active' : ''); ?>" href="<?php echo e(route('about')); ?>">About</a>
                                        </li>

                                        <li class="nav-item">
                                            <a class="nav-link <?php echo e(request()->is('services') ? 'active' : ''); ?>" href="<?php echo e(route('services')); ?>">Services</a>
                                        </li>
                                        <?php $__currentLoopData = $gasStations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $gasStation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="nav-item">
                                                <a class="nav-link" href="<?php echo e(route('gas-details', ['slug' => $gasStation->slug])); ?>"><?php echo e($gasStation->name ?? 'station Name'); ?>

                                                    <span class="sub-nav-toggler">
 													</span>
                                                </a>
                                                <?php if(count($gasStation->gasStations) > 0): ?>
                                                    <ul class="sub-menu">
                                                        <?php $__currentLoopData = $gasStation->gasStations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childGasStation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <li>
                                                                <a href="<?php echo e(route('gas-details', ['slug' => $childGasStation->slug])); ?>"><?php echo e($childGasStation->name); ?></a>



                                                            </li>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                    </ul>
                                                <?php endif; ?>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <li class="nav-item">
                                            <a class="nav-link <?php echo e(request()->is('contact-us') ? 'active' : ''); ?>" href="<?php echo e(route('contact-us')); ?>">Contact</a>
                                        </li>
                                    </ul>

                                </div>
                            </nav>
                        </div>
                    </div>









                </div>
            </div>
        </div>
    </div>

    <!-- Search Dropdown Area -->
    <div class="search-popup">
        <span class="search-back-drop"></span>

        <div class="search-inner">
            <div class="auto-container">
                <div class="upper-text">
                    <div class="text">Search for anything.</div>
                    <button class="close-search"><span class="la la-times"></span></button>
                </div>

                <form method="post" action="https://capricorn-theme.com/html/fossil/index.html">
                    <div class="form-group">
                        <input type="search" name="search-field" value="" placeholder="Search..." required="">
                        <button type="submit"><i class="la la-search"></i></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</header>
<?php /**PATH H:\wamp64\www\PRACTICE-SECTIONS\CLIENT-PROJECTS-DEVELOPMENT\fossil-gas-station\resources\views/frontend/includes/header.blade.php ENDPATH**/ ?>