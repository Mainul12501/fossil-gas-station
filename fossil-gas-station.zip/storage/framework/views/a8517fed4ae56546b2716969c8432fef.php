<?php $__env->startSection('title', 'Career Page'); ?>

<?php $__env->startSection('body'); ?>

    <!-- Breadcroumb Area -->

    <div class="breadcroumb-area bread-bg">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcroumb-title">
                        <h1>Career</h1>
                        <h6><a href="<?php echo e(route('home')); ?>">Home</a> / Dedicated Team</h6>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="team-area section-padding text-center pb-60">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-12 ">
                    <div class="section-title text-center">
                        <h6>Expert</h6>
                        <h2>Meet Our <b>Dedicated</b> Team</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                        <div class="single-team-member wow fadeInLeft" data-wow-delay=".2s">
                            <div class="team-member-bg" style="max-height: 300px; background-image: url(<?php echo e(asset($employee->profile_image ?? 'frontend/assets/img/team/1.jpg')); ?>); ">
                                <div class="team-content">
                                    <div class="team-title">
                                        <a href="javascript:void(0)"><?php echo e($employee->name); ?></a>
                                    </div>
                                    <div class="team-subtitle">
                                        <p><?php echo e($employee->gasStationEmployeeRoles[0]->name ?? 'Role Name'); ?></p>
                                    </div>
                                </div>
                                <div class="team-social">
                                    <ul>
                                        <li>
                                            <a href="<?php echo e($employee->fb ?? ''); ?>" target="_blank"><i class="fa fa-facebook-f" aria-hidden="true"></i> </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e($employee->x ?? ''); ?>" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i> </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e($employee->linkedin ?? ''); ?>" target="_blank"><i class="fa fa-linkedin" aria-hidden="true"></i> </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e($employee->whatsapp ?? ''); ?>" target="_blank"><i class="fa fa-whatsapp" aria-hidden="true"></i> </a>
                                        </li>

                                    </ul>
                                </div>
                            </div>

                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\wamp64\www\PRACTICE-SECTIONS\CLIENT-PROJECTS-DEVELOPMENT\fossil-gas-station\resources\views/frontend/common-pages/career.blade.php ENDPATH**/ ?>