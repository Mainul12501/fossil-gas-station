<!-- Favicon icon -->
<link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('/')); ?>backend/assets/images/favicon.png">
<!-- Custom CSS -->
<link rel="stylesheet" href="<?php echo e(asset('/')); ?>backend/dist/libs/toastr/toastr.min.css" />
<link rel="stylesheet" href="<?php echo e(asset('/')); ?>backend/dist/libs/jvectormap/jquery-jvectormap.css">
<!-- Custom CSS -->

<link href="<?php echo e(asset('/')); ?>backend/helper/helper.min.css" rel="stylesheet">
<link href="<?php echo e(asset('/')); ?>backend/dist/css/style.css" rel="stylesheet">

<?php echo $__env->yieldPushContent('style'); ?>
<?php /**PATH H:\wamp64\www\PRACTICE-SECTIONS\CLIENT-PROJECTS-DEVELOPMENT\fossil-gas-station\resources\views/backend/includes/asset/style.blade.php ENDPATH**/ ?>