<?php if(isset($childGasStation)): ?>
    <li>
        <div>
            <h4><a href="<?php echo e(route('gas-details', ['slug' => $childGasStation->slug])); ?>" class="nav-link"><?php echo e($childGasStation->name ?? 'Parent station'); ?></a></h4>
        </div>
        <?php if(isset($childGasStation->gasStations) && count($childGasStation->gasStations)): ?>
        <ol>

                <?php $__currentLoopData = $childGasStation->gasStations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childStation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('frontend.gas-stations.include-tree-view', ['childGasStation' => $childStation], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ol>
        <?php endif; ?>
    </li>
<?php endif; ?>
<?php /**PATH H:\wamp64\www\PRACTICE-SECTIONS\CLIENT-PROJECTS-DEVELOPMENT\fossil-gas-station\resources\views/frontend/gas-stations/include-tree-view.blade.php ENDPATH**/ ?>