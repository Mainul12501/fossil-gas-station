<?php $__env->startSection('title', 'Services'); ?>

<?php $__env->startSection('body'); ?>

    <!-- Breadcroumb Area -->

    <div class="breadcroumb-area bread-bg">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcroumb-title">
                        <h1>Services</h1>
                        <h6><a href="<?php echo e(route('home')); ?>">Home</a> / Services</h6>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Service Section  -->

    <div class="service-area gray-bg service-3 section-padding pt-100">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center ">
                    <div class="section-title">

                        <h2>We Provide <b>Fuel</b> Service <br> all type of <b>vehicles</b></h2>
                    </div>
                </div>
            </div>
            <div class="row">

                <div class="col-xl-4 col-lg-4 col-md-6 mb-30 common-height">
                    <div class="service-single wow fadeInLeft animated" data-wow-delay="400ms">
                        <div class="service-img-wrap">
                            <div class="service-thumb">

                                <img src="<?php echo e(asset('/')); ?>frontend/assets/img/gas-custom/1.jpeg" alt="">
                            </div>
                            <div class="services_icon">
                                <i class="flaticon-petrol"></i>
                            </div>
                        </div>
                        <div class="service-content">
                            <h5>Pure Octane</h5>
                            <p style="text-align: justify">Three times more detergent than the minimum required by the EPA and 30%* more than the minimum specified in the top tier Detergent Gasoline standard recommended by major car manufacturers.</p>

                        </div>
                    </div>
                </div>

                <div class="col-xl-4 col-lg-4 col-md-6 mb-30 common-height">
                    <div class="service-single wow fadeInLeft animated" data-wow-delay="500ms">
                        <div class="service-img-wrap">
                            <div class="service-thumb">

                                <img src="<?php echo e(asset('/')); ?>frontend/assets/img/gas-custom/9.jpeg" alt="">
                            </div>
                            <div class="services_icon">
                                <i class="flaticon-diesel"></i>
                            </div>
                        </div>
                        <div class="service-content">
                            <h5>Renewable Diesel</h5>
                            <div class="color-898a9c">
                                <ul class="nav">
                                    <p class="mb-1">Fueling a Greener Future</p>
                                    <p class="mb-1">Lower carbon footprint</p>
                                    <p class="mb-1">More efficient engine</p>
                                    <p class="mb-1">Quicker start, quieter running</p>
                                    <p class="mb-1">High performance</p>
                                </ul>
                            </div>

                        </div>
                    </div>
                </div>

                <div class="col-xl-4 col-lg-4 col-md-6 mb-30 common-height">
                    <div class="service-single wow fadeInLeft animated" data-wow-delay="600ms">
                        <div class="service-img-wrap">
                            <div class="service-thumb">

                                <img src="<?php echo e(asset('/')); ?>frontend/assets/img/gas-custom/14.jfif" alt="">
                            </div>
                            <div class="services_icon">
                                <i class="flaticon-biofuel"></i>
                            </div>
                        </div>
                        <div class="service-content">
                            <h5>Free Air</h5>
                            <div class="color-898a9c">
                                <p style="text-align: justify">As part of our commitment to customer convenience, all our gas customers enjoy complimentary access to tire inflation stations</p>
                            </div>

                        </div>
                    </div>
                </div>

                <div class="col-xl-4 col-lg-4 col-md-6 mb-30 common-height">
                    <div class="service-single wow fadeInLeft animated" data-wow-delay="100ms">
                        <div class="service-img-wrap">
                            <div class="service-thumb">

                                <img src="<?php echo e(asset('/')); ?>frontend/assets/img/gas-custom/6.jpeg" alt="">
                            </div>
                            <div class="services_icon">
                                <i class="flaticon-charging-station"></i>
                            </div>
                        </div>

                        <div class="service-content">
                            <h5>10 min Oil Change services</h5>
                            <p>Fast, Reliable, and Hassle-Free.</p>
                            <div class="color-898a9c">
                                <p style="text-align: justify">Get a premium oil change in just 10 minutes, tailored to your vehicle. Enjoy added convenience with a quick health check and top-quality oil for optimal performance and longevity</p>
                            </div>

                            
                        </div>
                    </div>
                </div>

                <div class="col-xl-4 col-lg-4 col-md-6 mb-30 common-height">
                    <div class="service-single wow fadeInLeft animated" data-wow-delay="300ms">
                        <div class="service-img-wrap">
                            <div class="service-thumb">

                                <img src="<?php echo e(asset('/')); ?>frontend/assets/img/gas-custom/12.jpg" alt="">
                            </div>
                            <div class="services_icon">
                                <i class="flaticon-car-wash"></i>
                            </div>
                        </div>
                        <div class="service-content">
                            <h5>Cas Washing</h5>
                            <p>A Sparkling Clean Ride Awaits!</p>
                            <div class="color-898a9c">
                                <p style="text-align: justify">Enjoy an eco-friendly, quick, and efficient car wash in under 15 minutes. Choose from customizable services with advanced technology, ensuring a spotless finish at affordable prices.</p>
                            </div>

                            
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-4 col-md-6 mb-30 common-height">
                    <div class="service-single wow fadeInLeft animated" data-wow-delay="300ms">
                        <div class="service-img-wrap">
                            <div class="service-thumb">

                                <img src="<?php echo e(asset('/')); ?>frontend/assets/img/gas-custom/13.jpg" alt="" style="min-height: 250px">
                            </div>
                            <div class="services_icon">
                                <i class="flaticon-car-wash"></i>
                            </div>
                        </div>
                        <div class="service-content">
                            <h5>Flat Tire</h5>
                            <p>Tire Care That Goes the Extra Mile.</p>
                            <div class="color-898a9c">
                                <p style="text-align: justify">Facing a flat tire? No worries! Our service ensures you’re back on the road quickly and safely with the necessary support.</p>
                            </div>

                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Extra Service -->

    <div id="xtra" class="xtra-service-wrap section-padding">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center ">
                    <div class="section-title">
                        <h6>We Also Do</h6>
                        <h2>More <b>Additional</b> Service in <br> Filling Station</h2>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-3 col-md-6 col-sm-12 ">
                    <div class="xtra-serve-area mt-50 wow fadeInLeft" data-wow-delay=".3s">
                        <img src="<?php echo e(asset('/')); ?>frontend/assets/img/xtra/01.jpg" alt="">
                        <h5>Car Evacaution</h5>

                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-12">
                    <div class="xtra-serve-area mt-50 bg-cover wow fadeInLeft" data-wow-delay=".4s">
                        <img src="<?php echo e(asset('/')); ?>frontend/assets/img/xtra/02.jpg" alt="">
                        <h5>Emergency Charging</h5>

                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-12">
                    <div class="xtra-serve-area mt-50 bg-cover wow fadeInRight" data-wow-delay=".4s">
                        <img src="<?php echo e(asset('/')); ?>frontend/assets/img/xtra/03.jpg" alt="">
                        <h5>Wheels Pumping</h5>

                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-12">
                    <div class="xtra-serve-area mt-50 bg-cover wow fadeInRight" data-wow-delay=".3s">
                        <img src="<?php echo e(asset('/')); ?>frontend/assets/img/xtra/04.jpg" alt="">
                        <h5>Engine Repair</h5>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Service Area -->




























































































































<?php $__env->stopSection(); ?>
<?php $__env->startPush('style'); ?>
    <style>
        .color-898a9c {color: #898a9c!important;}
        .service-content ul li  {padding-left: 0px;}
        .service-thumb {max-height: 250px}
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        $(function () {
            let height = 0;
            $('.common-height').each(function () {
                if ($(this).height() > height) {
                    height = $(this).height();
                }
            });
            $('.common-height .service-single').css('height', height+'px');
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\wamp64\www\PRACTICE-SECTIONS\CLIENT-PROJECTS-DEVELOPMENT\fossil-gas-station\resources\views/frontend/service/services.blade.php ENDPATH**/ ?>