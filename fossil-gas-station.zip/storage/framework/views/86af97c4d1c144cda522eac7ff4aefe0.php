<?php $__env->startSection('title', 'Basic Setting'); ?>
<?php $__env->startSection('breadcrumb', 'Basic Setting'); ?>

<?php $__env->startSection('body'); ?>

    <div class="row py-5">
        <div class="col-md-10 mx-auto">
            <div class="card">
                <div class="card-header bg-primary">
                    <h4 class="text-white float-start">Basic Setting</h4>



                </div>
                <div class="card-body">
                    <form action="<?php echo e(isset($basicSetting) ? route('basic-settings.update', $basicSetting->id) : route('basic-settings.store')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php if(isset($basicSetting)): ?>
                            <?php echo method_field('put'); ?>
                        <?php endif; ?>
                        <div class="row">
                            <div class="col-md-6">
                                <label for="">Site Title <span class="text-danger">(required)</span></label>
                                <input type="text" name="site_title" <?php echo e(isset($isShown) ? 'readonly' : ''); ?> class="form-control" value="<?php echo e(isset($basicSetting) ? $basicSetting->site_title : ''); ?>" />
                            </div>
                            <div class="col-md-6">
                                <label for="">Meta Title </label>
                                <input type="text" name="meta_title" <?php echo e(isset($isShown) ? 'readonly' : ''); ?> class="form-control" value="<?php echo e(isset($basicSetting) ? $basicSetting->meta_title : ''); ?>" />
                            </div>
                            <div class="col-md-6 mt-1">
                                <label for="">Phone Number </label>
                                <input type="text" name="phone" <?php echo e(isset($isShown) ? 'readonly' : ''); ?> class="form-control" value="<?php echo e(isset($basicSetting) ? $basicSetting->phone : ''); ?>" />
                            </div>
                            <div class="col-md-6 mt-1">
                                <label for="">Email </label>
                                <input type="text" name="email" <?php echo e(isset($isShown) ? 'readonly' : ''); ?> class="form-control" value="<?php echo e(isset($basicSetting) ? $basicSetting->email : ''); ?>" />
                            </div>
                        </div>
                        <div class="row mt-2">
                            <div class="col-md-6">
                                <label for="">Site Moto</label>
                                <textarea name="site_moto" <?php echo e(isset($isShown) ? 'disabled' : ''); ?> class="form-control" id="elm1" cols="30" rows="2"><?php echo isset($basicSetting) ? $basicSetting->site_moto : ''; ?></textarea>
                            </div>
                            <div class="col-md-6">
                                <label for="">Site Footer Info</label>
                                <textarea name="site_description" <?php echo e(isset($isShown) ? 'disabled' : ''); ?> class="form-control" id="elm1" cols="30" rows="2"><?php echo isset($basicSetting) ? $basicSetting->site_description : ''; ?></textarea>
                            </div>
                            <div class="col-md-6 mt-1">
                                <label for="">Meta Description</label>
                                <textarea name="meta_description" <?php echo e(isset($isShown) ? 'disabled' : ''); ?> class="form-control" id="elm1" cols="30" rows="2"><?php echo isset($basicSetting) ? $basicSetting->meta_description : ''; ?></textarea>
                            </div>
                            <div class="col-md-6 mt-1">
                                <label for="">Corporate Office Address</label>
                                <textarea name="corporate_office" <?php echo e(isset($isShown) ? 'disabled' : ''); ?> class="form-control" id="elm1" cols="30" rows="2"><?php echo isset($basicSetting) ? $basicSetting->corporate_office : ''; ?></textarea>
                            </div>
                        </div>
                        <div class="mt-2">
                            <label for="">Office Address</label>
                            <textarea name="address" <?php echo e(isset($isShown) ? 'disabled' : ''); ?> class="form-control" id="elm1" cols="30" rows="2"><?php echo isset($basicSetting) ? $basicSetting->address : ''; ?></textarea>
                        </div>

                        <div class="mt-2">
                            <label for="">SEO Header</label>
                            <textarea name="seo_header" <?php echo e(isset($isShown) ? 'disabled' : ''); ?> class="form-control" id="elm1" cols="30" rows="2"><?php echo isset($basicSetting) ? $basicSetting->seo_header : ''; ?></textarea>
                        </div>
                        <div class="mt-2">
                            <label for="">SEO Footer</label>
                            <textarea name="seo_footer" <?php echo e(isset($isShown) ? 'disabled' : ''); ?> class="form-control" id="elm1" cols="30" rows="2"><?php echo isset($basicSetting) ? $basicSetting->seo_footer : ''; ?></textarea>
                        </div>
                        <div class="row mt-2">
                            <div class="col-md-6">
                                <label for="">FB Profile Link</label>
                                <input type="text" name="fb" <?php echo e(isset($isShown) ? 'readonly' : ''); ?> class="form-control" value="<?php echo e(isset($basicSetting) ? $basicSetting->fb : ''); ?>" />
                            </div>
                            <div class="col-md-6">
                                <label for="">Whatsapp Number</label>
                                <input type="text" name="whatsapp" <?php echo e(isset($isShown) ? 'readonly' : ''); ?> class="form-control" value="<?php echo e(isset($basicSetting) ? $basicSetting->whatsapp : ''); ?>" />
                            </div>
                            <div class="col-md-6">
                                <label for="">Instagram Profile Link</label>
                                <input type="text" name="insta" <?php echo e(isset($isShown) ? 'readonly' : ''); ?> class="form-control" value="<?php echo e(isset($basicSetting) ? $basicSetting->insta : ''); ?>" />
                            </div>
                            <div class="col-md-6">
                                <label for="">Skype Profile Link</label>
                                <input type="text" name="skype" <?php echo e(isset($isShown) ? 'readonly' : ''); ?> class="form-control" value="<?php echo e(isset($basicSetting) ? $basicSetting->skype : ''); ?>" />
                            </div>
                            <div class="col-md-6">
                                <label for="">Linkedin Profile Link</label>
                                <input type="text" name="linkedin" <?php echo e(isset($isShown) ? 'readonly' : ''); ?> class="form-control" value="<?php echo e(isset($basicSetting) ? $basicSetting->linkedin : ''); ?>" />
                            </div>
                        </div>
                        <div class="row mt-2">
                            <div class="col-md-6">
                                <label for="">Logo</label>
                                <?php if(!isset($isShown)): ?>
                                    <input type="file" name="logo" class="form-control" accept="image/*" />
                                <?php endif; ?>
                                <?php if(isset($basicSetting->logo)): ?>
                                    <img src="<?php echo e(asset($basicSetting->logo)); ?>" alt="" style="height: 60px" />
                                <?php endif; ?>
                            </div>
                            <div class="col-md-6">
                                <label for="">Favicon</label>
                                <?php if(!isset($isShown)): ?>
                                    <input type="file" name="favicon" class="form-control" accept="image/vnd.microsoft.icon" />
                                <?php endif; ?>
                                <?php if(isset($basicSetting->favicon)): ?>
                                    <img src="<?php echo e(asset($basicSetting->favicon)); ?>" alt="" style="height: 16px" />
                                <?php endif; ?>
                            </div>

                        </div>









                        <?php if(!isset($isShown)): ?>
                        <div class="mt-2">
                            <input type="submit" class="btn btn-success btn-sm float-end" value="<?php echo e(isset($basicSetting) ? 'Update' : 'Create'); ?> Basic Setting" />
                        </div>
                        <?php endif; ?>
                    </form>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <?php echo $__env->make('backend.includes.asset.plugin-files.select-2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--tinymce js-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/tinymce/5.3.2/tinymce.min.js" integrity="sha512-9w/jRiVYhkTCGR//GeGsRss1BJdvxVj544etEHGG1ZPB9qxwF7m6VAeEQb1DzlVvjEZ8Qv4v8YGU8xVPPgovqg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <script>

        tinymce.init({
            selector: 'textarea',
            height: 200,
            menubar: false,
            plugins: [
                'advlist autolink lists link image charmap print preview anchor',
                'searchreplace visualblocks code fullscreen',
                'insertdatetime media table paste code help wordcount'
            ],
            toolbar: 'undo redo | formatselect | ' +
                'bold italic backcolor | alignleft aligncenter ' +
                'alignright alignjustify | bullist numlist outdent indent | ' +
                'removeformat | help',
            content_style: 'body { font-family:Helvetica,Arial,sans-serif; font-size:14px }'
        });


    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\wamp64\www\PRACTICE-SECTIONS\CLIENT-PROJECTS-DEVELOPMENT\fossil-gas-station\resources\views/backend/basic-setting/create.blade.php ENDPATH**/ ?>