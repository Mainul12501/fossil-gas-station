<?php

return [
    'name' => 'SiteSettings/BasicSetting',
];
