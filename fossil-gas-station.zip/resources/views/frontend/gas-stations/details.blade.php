@extends('frontend.master')

@section('title', 'Station Details')

@section('body')

@endsection
