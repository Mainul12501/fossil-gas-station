<!-- INTERNAL Summernote Editor js -->
<script src="{{ asset('/') }}backend/assets/plugins/summernote-editor/summernote1.js"></script>
<script src="{{ asset('/') }}backend/assets/js/summernote.js"></script>


{{--run summernote during edit by ajax--}}
{{--$('#summernote').summernote('destroy');--}}
{{--$('textarea[name="note"]').html(data.note);--}}
{{--$("#summernote").summernote({height:70,inheritPlaceholder: true})--}}
