<?php

namespace App\Models\Backend;

use App\Models\Scopes\Searchable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class HomePageSlider extends Model
{
    use HasFactory;
    use Searchable;

    protected $fillable = [
        'banner_image',
        'tiny_title',
        'title',
        'description',
        'status',
    ];

    protected $searchableFields = ['*'];

    protected $table = 'home_page_sliders';
}
